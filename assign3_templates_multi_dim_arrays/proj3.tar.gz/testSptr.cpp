/*
 * testSptr.cpp
 *
 *  Created on: May 16, 2012
 *      Author: devonmcb
 */
#include "Sptr.hpp"
#include <iostream>
#include <typeinfo>  //for 'typeid'
#include <string>
#include <cstring>

using namespace std;

class A {
  public:
    A(const char * x){
    	/* ===========================================
    	 * I'm still not used to the following, having
    	 * started with scripting languages and Java.
    	 * It seems barbaric! Uncivilized! Antique!
    	 * ========================================*/
    	// new char [some-size] returns pointer
        c = new char[strlen(x) + 1]; // allocates space on heap
        strcpy(c, x); //copies characters from x into space at c
    }
    virtual ~A(){ delete []c; };
    void foo(int i){
    	cout<<i<<" is an int."<<endl;
    }
  //private: // commented out for ease of testing
    char * c;
};


class B : public A {
  public:

    B() : A("B"), buf(new char[10]) {}

    ~B() { delete [] buf; }

    char * buf; // public for ease of testing here.

    void setBuf(const char * n){
		buf = new char[strlen(n) + 1];
		strcpy(buf,n);
    }

  //private: // moved to public for ease of testing
};

//#if 0 // commenting out main() so as to run another main somewheres else

using namespace cs540;

int main(){
	Sptr<A> s1;
	Sptr<A> s2(new A("a string"));
	cout<< "This is Sptr<A>s2->c: "<< s2->c << endl;
	cout<< "count is: "<<s2.counter->count<<endl;

	/********************TEST COPY CTOR***************************/
	Sptr<A> s3(s2);
	cout<< "after copy constructor, ";
	cout<< "count is: "<<s2.counter->count<<endl;

	/* tests conforming more closely to Prof. Chiu's assignment */

	Sptr<A> ap1(new A("a string"));
	Sptr<A> ap2; // Initialized to point to null pointer.
	cout<<" Arrow operator: ";
	ap1->foo(1234); // Arrow operator.
	cout<<"count after 'Sptr<B> bp1(new B);' is ";
	Sptr<B> bp1(new B);
	cout<<bp1.getCount()<<endl;


    cout<<"count after 'Sptr<B> bp2(bp1);' (Copy constructor) is ";
	Sptr<B> bp2(bp1); // Copy constructor.
	cout<<bp1.getCount()<<endl;

	cout<<"count after Sptr<A> ap3(bp2); (Automatic conversion to base class pointer) is ";
	Sptr<A> ap3(bp2); // Automatic conversion to base class pointer.
	cout<<bp1.getCount()<<endl;

	cout<<"count after ap3 = bp2; (Automatic conversion to base class pointer) is ";
	ap3 = bp2; // Automatic conversion to base class pointer.
	cout<<bp1.getCount()<<endl;

	cout<<"count after bp1 = bp2; (Self-assignment must be safe) is ";
	bp1 = bp2; // Self-assignment must be safe.
	cout<<bp1.getCount()<<endl;

	cout<<"count after ap1 = bp2; (Self-assignment must be safe) is ";
	ap1 = bp2; // Self-assignment must be safe.
	cout<<bp1.getCount()<<endl;

	cout<<endl; cout<<"returned OK"<<endl; 	cout<<"==========="<<endl;
	return 0;
}
//#endif // end commenting out main()


